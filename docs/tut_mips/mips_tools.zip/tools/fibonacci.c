//#include <stdio.h>
//#include <stdlib.h>

int fibo(int data_in)
{
	int n_anterior1,n_anterior2,n_fibonacci;
	int n, n_max; 	

	n_anterior1=1; /*f(n-1) o número de fibonacci requer da suma dos dois valores anteriores */
  	n_anterior2=0; /*f(n-2) o número de fibonacci requer da suma dos dois valores anteriores */
  	n_fibonacci = 0;
	n_max=data_in;  /* n_max é o valor do número de fibonacci a avaliar.*/

	if ( n_max==1 || n_max==0 ){
		n_fibonacci=n_max;
		//printf("%i \n",n_fibonacci);
		return n_fibonacci;
	}else{
		while(n_max>1) {
			n_fibonacci=n_anterior1+n_anterior2; /* f(n)=f(n-1)+f(n-2)*/ 
			n_anterior2=n_anterior1; /* necessário para ter a próxima operação f(n-2)=f(n-1)*/
			n_anterior1=n_fibonacci; /* necessário para ter  a próxima operação f(n-1)=f(n)*/
			n_max=n_max-1; /* número de iterações */ 
		}
		//printf("%i \n",n_fibonacci);
		return n_fibonacci;
		
	}
}

int main ()
{

	int data_available_o, status_o;
	int data_o;
	int data_in;

	status_o=0;
	data_available_o =0;
	data_o =0;
	data_in =7;
	status_o=1;
	/*while(!go_i);*/

	data_o = fibo(data_in);
	data_available_o =1;
	status_o = 2;
	//repeticoes = 0;
	/*while (!data_accepted_i);*/
	//}

	return 0;


}