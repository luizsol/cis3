#include "plasma.h"

# define num_aluno ??? // colocar o seu n�mero 

void OS_Init(void);


int main()
{
   unsigned long number, counter, i=0;
   int x[22];
   
   //OS_Init implementado em no_os_2553.c

   OS_Init();

   //inicializa��o do vetor com valores de n�meros primos.

   x[1] = 3;
   x[2] = 5;
   x[3] = 7;
   x[4] = 11;
   x[5] = 13;
   x[6] = 17;
   x[7] = 19;
   x[8] = 23;
   x[9] = 29;
   x[10] = 31;
   x[11] = 37;
   x[12] = 41;
   x[13] = 43;
   x[14] = 47;
   x[15] = 53;
   x[16] = 59;
   x[17] = 61;
   x[18] = 67;
   x[19] = 71;
   x[20] = 73;
   x[21] = 79;

   MemoryWrite(MAIN_COUNT+4, x[num_aluno]);
// na linha acima, subsituir com o seu num_aluno

   number = 1;
   for(i = 0;; ++i)
   {
     if (number >= 131072) /* equivale ao numero 0x20000 */
        number = 1;
     else
        number *= 2;
      
      MemoryWrite(MAIN_COUNT, number);

      counter=MemoryRead(MAIN_COUNT) + 1;
        
	MemoryWrite(MAIN_COUNT, counter);
 
   }
}
